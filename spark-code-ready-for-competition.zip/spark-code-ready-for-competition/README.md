# HOW TO BEGIN PROGRAMMING
### 1. Place the PS2X_lib folder inside Documents\Arduino\libraries
### 2. Open the spark_code.ino file with the Arduino IDE (Integrated Developing Environment)
### 3. Connect the boebot to your computer with the USB cable to begin programming!
